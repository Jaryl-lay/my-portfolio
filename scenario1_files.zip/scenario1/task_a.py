"""
Task A: Web Scraping from Amazon
---------------------------------
- Search "router" on Amazon, retrieve first 300 results
- Extract: Product Description, Price, User Rating
- Save to datascrap.csv
- Filter out rows with empty fields -> filtered.xlsx
- Email filtered.xlsx to your email address
- Triggered by Shift + 1
"""

import csv
import os
import time
import smtplib
import openpyxl
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email import encoders
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# ============================================================
# CONFIGURE YOUR EMAIL CREDENTIALS HERE
# ============================================================
SENDER_EMAIL    = "your_email@gmail.com"
SENDER_PASSWORD = "your_app_password"     # Use a Gmail App Password
RECEIVER_EMAIL  = "your_email@gmail.com"
# ============================================================

OUTPUT_CSV     = "datascrap.csv"
OUTPUT_XLSX    = "filtered.xlsx"
SEARCH_TERM    = "router"
MAX_RESULTS    = 300


def get_driver():
    """Set up headless Chrome driver."""
    options = Options()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--window-size=1920,1080")
    options.add_argument(
        "user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    )
    driver = webdriver.Chrome(options=options)
    return driver


def scrape_amazon():
    """Scrape Amazon search results for 'router'."""
    driver = get_driver()
    results = []
    page = 1

    print(f"[Task A] Starting Amazon scrape for '{SEARCH_TERM}'...")

    try:
        while len(results) < MAX_RESULTS:
            url = (
                f"https://www.amazon.com/s?k={SEARCH_TERM}"
                f"&page={page}"
            )
            driver.get(url)
            time.sleep(3)

            # Wait for results to load
            try:
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located(
                        (By.CSS_SELECTOR, "[data-component-type='s-search-result']")
                    )
                )
            except Exception:
                print(f"[Task A] No results found on page {page}. Stopping.")
                break

            items = driver.find_elements(
                By.CSS_SELECTOR, "[data-component-type='s-search-result']"
            )

            if not items:
                print(f"[Task A] Empty page {page}. Stopping.")
                break

            for item in items:
                if len(results) >= MAX_RESULTS:
                    break
                try:
                    # Product description
                    desc_el = item.find_element(
                        By.CSS_SELECTOR, "h2 .a-link-normal span"
                    )
                    description = desc_el.text.strip()
                except Exception:
                    description = ""

                try:
                    # Price (whole + fraction)
                    price_whole = item.find_element(
                        By.CSS_SELECTOR, ".a-price-whole"
                    ).text.strip()
                    price_frac = item.find_element(
                        By.CSS_SELECTOR, ".a-price-fraction"
                    ).text.strip()
                    price = f"${price_whole}{price_frac}"
                except Exception:
                    price = ""

                try:
                    # User rating
                    rating_el = item.find_element(
                        By.CSS_SELECTOR, ".a-icon-alt"
                    )
                    rating = rating_el.get_attribute("innerHTML").strip()
                    # Keep only numeric part e.g. "4.5 out of 5 stars"
                    rating = rating.split(" out")[0]
                except Exception:
                    rating = ""

                results.append({
                    "Product Description": description,
                    "Price": price,
                    "User Rating": rating,
                })

            print(f"[Task A] Page {page} scraped. Total results: {len(results)}")
            page += 1

            # Amazon usually shows ~16 results per page; ~19 pages for 300
            if page > 20:
                break

    finally:
        driver.quit()

    return results


def save_to_csv(results):
    """Save all results to datascrap.csv."""
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
        fieldnames = ["Product Description", "Price", "User Rating"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)
    print(f"[Task A] Saved {len(results)} rows to '{OUTPUT_CSV}'.")


def filter_to_xlsx():
    """Read datascrap.csv, remove rows with any empty field, save filtered.xlsx."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Filtered Results"

    # Headers
    headers = ["Product Description", "Price", "User Rating"]
    for col, h in enumerate(headers, 1):
        ws.cell(row=1, column=col, value=h)

    kept = 0
    with open(OUTPUT_CSV, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        row_num = 2
        for row in reader:
            # Remove rows that have any empty field
            if all(row[h].strip() for h in headers):
                ws.cell(row=row_num, column=1, value=row["Product Description"])
                ws.cell(row=row_num, column=2, value=row["Price"])
                ws.cell(row=row_num, column=3, value=row["User Rating"])
                row_num += 1
                kept += 1

    wb.save(OUTPUT_XLSX)
    print(f"[Task A] Filtered {kept} clean rows saved to '{OUTPUT_XLSX}'.")


def send_email():
    """Send filtered.xlsx to the configured email address."""
    msg = MIMEMultipart()
    msg["From"]    = SENDER_EMAIL
    msg["To"]      = RECEIVER_EMAIL
    msg["Subject"] = "Amazon Router Search – Filtered Results"

    body = (
        "Hi,\n\n"
        "Please find attached the filtered Amazon search results for 'router'.\n\n"
        "Regards,\nTask A Bot"
    )
    msg.attach(MIMEText(body, "plain"))

    with open(OUTPUT_XLSX, "rb") as f:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(f.read())
    encoders.encode_base64(part)
    part.add_header(
        "Content-Disposition",
        f"attachment; filename={OUTPUT_XLSX}",
    )
    msg.attach(part)

    with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
        server.login(SENDER_EMAIL, SENDER_PASSWORD)
        server.sendmail(SENDER_EMAIL, RECEIVER_EMAIL, msg.as_string())

    print(f"[Task A] Email sent to {RECEIVER_EMAIL}.")


def run_task_a():
    print("=" * 50)
    print("TASK A: Amazon Web Scraping")
    print("=" * 50)
    results = scrape_amazon()
    save_to_csv(results)
    filter_to_xlsx()
    send_email()
    print("[Task A] DONE.\n")


if __name__ == "__main__":
    run_task_a()
