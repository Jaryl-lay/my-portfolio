"""
Task C: Automate IP Address Check via Command Prompt
------------------------------------------------------
- Open Command Prompt (cmd)
- Run 'ipconfig' command
- Capture the output
- Save output to 'log.txt'
- Triggered by Shift + 3
"""

import subprocess
import os
import time
from datetime import datetime

OUTPUT_FILE = "log.txt"


def run_ipconfig():
    """
    Run 'ipconfig' via Command Prompt and capture its output.
    Works on Windows. On non-Windows systems, falls back to
    'ip addr' or 'ifconfig' for cross-platform compatibility.
    """
    print("[Task C] Running ipconfig via Command Prompt...")

    if os.name == "nt":
        # Windows: use cmd /c ipconfig to mimic opening Command Prompt
        result = subprocess.run(
            ["cmd", "/c", "ipconfig"],
            capture_output=True,
            text=True
        )
    else:
        # Linux / macOS fallback
        result = subprocess.run(
            ["ip", "addr"],
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            result = subprocess.run(
                ["ifconfig"],
                capture_output=True,
                text=True
            )

    output = result.stdout
    if result.stderr:
        output += "\nSTDERR:\n" + result.stderr

    return output


def save_log(output):
    """Save ipconfig output to log.txt with a timestamp header."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        f.write(f"IP Configuration Log\n")
        f.write(f"Generated: {timestamp}\n")
        f.write("=" * 60 + "\n\n")
        f.write(output)
    print(f"[Task C] Output saved to '{OUTPUT_FILE}'.")


def run_task_c():
    print("=" * 50)
    print("TASK C: IP Address Check")
    print("=" * 50)

    output = run_ipconfig()

    # Print to console so user can see it (mirrors Figure 4)
    print("\n--- ipconfig output ---")
    print(output)
    print("-----------------------\n")

    save_log(output)
    print("[Task C] DONE.\n")


if __name__ == "__main__":
    run_task_c()
