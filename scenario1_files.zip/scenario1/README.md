# Project Scenario 1 – RPA Automation
## Module IT49471 | Higher Nitec in IT Applications Development

---

## Files Included

| File | Purpose |
|---|---|
| `main.py` | **Start here.** Registers Shift+1/2/3 hotkeys |
| `task_a.py` | Task A – Amazon scraping bot |
| `task_b.py` | Task B – Attendance marking bot |
| `task_c.py` | Task C – IP address check bot |
| `attendance.xlsx` | Sample attendance data (input for Task B) |
| `attendance.html` | Attendance form page (input for Task B) |
| `requirements.txt` | Python package list |

---

## Setup Instructions

### Step 1 – Install Python packages
Open Command Prompt in this folder and run:
```
pip install -r requirements.txt
```

### Step 2 – Install ChromeDriver
- Check your Chrome version: Chrome menu → Help → About Google Chrome
- Download the matching ChromeDriver from:
  https://googlechromelabs.github.io/chrome-for-testing/
- Extract and place `chromedriver.exe` in this folder **or** add it to your system PATH

### Step 3 – Configure Email (Task A only)
Open `task_a.py` and edit these lines near the top:
```python
SENDER_EMAIL    = "your_email@gmail.com"
SENDER_PASSWORD = "your_app_password"   # Gmail App Password
RECEIVER_EMAIL  = "your_email@gmail.com"
```
> **Gmail App Password**: Go to https://myaccount.google.com/apppasswords
> Create a new App Password for "Mail" and paste it as SENDER_PASSWORD.

### Step 4 – Run the bot runner
```
python main.py
```

---

## Hotkeys

| Hotkey | Task |
|---|---|
| **Shift + 1** | Task A – Scrape Amazon for "router" (→ datascrap.csv → filtered.xlsx → email) |
| **Shift + 2** | Task B – Read attendance.xlsx → fill attendance.html → screenshot PNG |
| **Shift + 3** | Task C – Run ipconfig → save to log.txt |
| **Shift + Q** | Quit the bot runner |

---

## Output Files Created

| File/Folder | Created by |
|---|---|
| `datascrap.csv` | Task A |
| `filtered.xlsx` | Task A |
| `Attendance Records/attendance_YYYY-MM-DD.png` | Task B |
| `log.txt` | Task C |

---

## Notes
- All scripts must be run from the **same folder** containing `attendance.xlsx` and `attendance.html`
- Task A requires a stable internet connection; Amazon may occasionally block scrapers
- Task B opens a visible Chrome window so you can see the form being filled before the screenshot
- Task C works on Windows (uses `ipconfig`). On Mac/Linux it uses `ip addr` or `ifconfig` instead
