"""
Main Bot Runner – Project Scenario 1
======================================
Registers keyboard hotkeys:
  Shift + 1  ->  Task A (Amazon web scraping)
  Shift + 2  ->  Task B (Attendance marking)
  Shift + 3  ->  Task C (IP address check)
  Shift + Q  ->  Quit the program

Run this script first, then press the hotkeys as needed.

Requirements:
    pip install selenium openpyxl keyboard

    ChromeDriver must be installed and on your PATH.
    Download from: https://googlechromelabs.github.io/chrome-for-testing/
    Match your Chrome browser version.

Email setup for Task A:
    Edit SENDER_EMAIL, SENDER_PASSWORD, RECEIVER_EMAIL in task_a.py.
    For Gmail, use an App Password (not your main password):
    https://myaccount.google.com/apppasswords
"""

import threading
import keyboard   # pip install keyboard

from task_a import run_task_a
from task_b import run_task_b
from task_c import run_task_c


def safe_run(fn, name):
    """Run a task in a thread so hotkeys stay responsive."""
    def wrapper():
        try:
            fn()
        except Exception as e:
            print(f"[ERROR] {name} failed: {e}")
    t = threading.Thread(target=wrapper, daemon=True)
    t.start()


def main():
    print("=" * 55)
    print("  RPA Bot Runner – Project Scenario 1")
    print("=" * 55)
    print("  Shift + 1  ->  Task A: Amazon Web Scraping")
    print("  Shift + 2  ->  Task B: Attendance Marking")
    print("  Shift + 3  ->  Task C: IP Address Check")
    print("  Shift + Q  ->  Quit")
    print("=" * 55)
    print("  Listening for hotkeys...\n")

    keyboard.add_hotkey("shift+1", lambda: safe_run(run_task_a, "Task A"))
    keyboard.add_hotkey("shift+2", lambda: safe_run(run_task_b, "Task B"))
    keyboard.add_hotkey("shift+3", lambda: safe_run(run_task_c, "Task C"))
    keyboard.add_hotkey("shift+q", keyboard.unhook_all)

    keyboard.wait("shift+q")
    print("\nBot Runner stopped. Goodbye!")


if __name__ == "__main__":
    main()
