"""
Task B: Automate Attendance Marking
-------------------------------------
- Read attendance data from attendance.xlsx
- Open attendance.html in browser
- Mark each student's attendance (Present/Absent/MC/AL + Late hours)
- Take a screenshot, save as PNG in 'Attendance Records' folder
- Triggered by Shift + 2
"""

import os
import time
from datetime import date
import openpyxl
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

ATTENDANCE_XLSX = "attendance.xlsx"
ATTENDANCE_HTML = "attendance.html"
OUTPUT_FOLDER   = "Attendance Records"

# Column indices in attendance.xlsx (1-based)
COL_STUDENT_ID  = 1   # e.g. S7777777E
COL_NAME        = 2   # e.g. CHOON CHUAN
COL_PRESENT     = 3   # 1 = Present, 0 = Absent
COL_STATUS      = 4   # MC / AL / - (dash means no special status)
COL_LATE_HRS    = 5   # number of late hours


def read_attendance_xlsx():
    """Return list of dicts representing each student row."""
    wb = openpyxl.load_workbook(ATTENDANCE_XLSX)
    ws = wb.active
    students = []
    # Skip header row (row 1)
    for row in ws.iter_rows(min_row=2, values_only=True):
        student_id, name, present, status, late_hrs = (
            row[COL_STUDENT_ID - 1],
            row[COL_NAME - 1],
            row[COL_PRESENT - 1],
            row[COL_STATUS - 1],
            row[COL_LATE_HRS - 1],
        )
        if student_id:
            students.append({
                "id":       str(student_id).strip(),
                "name":     str(name).strip() if name else "",
                "present":  int(present) if present is not None else 1,
                "status":   str(status).strip() if status else "-",
                "late_hrs": int(late_hrs) if late_hrs else 0,
            })
    return students


def determine_attendance_value(student):
    """
    Decide which radio button value to select based on xlsx data:
      - If status is MC  -> select MC
      - If status is AL  -> select AL
      - If present == 1  -> select Present
      - If present == 0  -> select Absent
    """
    status = student["status"].upper()
    if status == "MC":
        return "MC"
    if status == "AL":
        return "AL"
    return "Present" if student["present"] == 1 else "Absent"


def mark_attendance(driver, students):
    """Fill in radio buttons and late-hours inputs for each student."""
    for student in students:
        sid   = student["id"]
        value = determine_attendance_value(student)
        late  = student["late_hrs"]

        # Click the correct radio button
        # Radio name pattern: att_<StudentID>
        try:
            radio = driver.find_element(
                By.CSS_SELECTOR,
                f"input[name='att_{sid}'][value='{value}']"
            )
            driver.execute_script("arguments[0].click();", radio)
            print(f"  [Task B] {sid} ({student['name']}) -> {value}")
        except Exception as e:
            print(f"  [Task B] WARNING: Could not find radio for {sid}: {e}")

        # Set late hours input
        try:
            late_input = driver.find_element(
                By.CSS_SELECTOR, f"input[name='late_{sid}']"
            )
            late_input.clear()
            late_input.send_keys(str(late))
        except Exception:
            pass  # Not all students may have a late input issue

        time.sleep(0.3)


def take_screenshot(driver):
    """Save a PNG screenshot into the Attendance Records folder."""
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
    today = date.today().strftime("%Y-%m-%d")
    filename = os.path.join(OUTPUT_FOLDER, f"attendance_{today}.png")
    driver.save_screenshot(filename)
    print(f"[Task B] Screenshot saved: {filename}")
    return filename


def run_task_b():
    print("=" * 50)
    print("TASK B: Attendance Marking Automation")
    print("=" * 50)

    # Read data from xlsx
    students = read_attendance_xlsx()
    print(f"[Task B] Loaded {len(students)} students from '{ATTENDANCE_XLSX}'.")

    # Build full file:// path to attendance.html
    html_path = os.path.abspath(ATTENDANCE_HTML)
    html_url  = f"file:///{html_path}".replace("\\", "/")

    # Launch Chrome
    options = Options()
    options.add_argument("--window-size=1280,800")
    # Remove headless so the screenshot captures the rendered page visually
    # options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    driver = webdriver.Chrome(options=options)

    try:
        driver.get(html_url)
        time.sleep(1)

        # Wait for the form to load
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "table"))
        )

        # Mark attendance
        mark_attendance(driver, students)
        time.sleep(1)

        # Take screenshot
        take_screenshot(driver)

    finally:
        driver.quit()

    print("[Task B] DONE.\n")


if __name__ == "__main__":
    run_task_b()
